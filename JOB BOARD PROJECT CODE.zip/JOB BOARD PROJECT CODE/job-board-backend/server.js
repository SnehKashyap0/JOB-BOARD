const express = require('express');
const mongoose = require('mongoose');
const connectDB = require('./config/db');
const cors = require('cors');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json()); // parse JSON request body
const auth = require('../middleware/auth');
router.post('/', auth, async (req, res) => {
  // Only logged-in users can post jobs
});

// DB connection
connectDB();


//middleware
const jobRoutes = require('./routes/jobRoutes');
app.use('/api/jobs', jobRoutes);

// Connect MongoDB
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('MongoDB connected'))
.catch(err => console.error(err));

// Simple root route
app.get('/', (req, res) => {
  res.send('Job Board API is running');
});

// Routes
app.use('/api/jobs', require('./routes/jobRoutes'));
app.use('/api/auth', require('./routes/authRoutes'));


app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

