document.addEventListener('DOMContentLoaded', () => {
  // Rotating messages
  const messages = [
    "Discover thousands of jobs.",
    "Post your job openings easily.",
    "Connect with top employers.",
  ];
  let messageIndex = 0;
  const messageElement = document.getElementById('rotating-message');

  function rotateMessage() {
    messageElement.textContent = messages[messageIndex];
    messageIndex = (messageIndex + 1) % messages.length;
  }

  rotateMessage();
  setInterval(rotateMessage, 4000);

  // Sample jobs data for search demo
  const jobs = [
    { title: "Frontend Developer", company: "Tech Solutions", location: "New York, NY" },
    { title: "Backend Engineer", company: "Innovatech", location: "San Francisco, CA" },
    { title: "UI/UX Designer", company: "Creative Minds", location: "Remote" },
    { title: "Marketing Specialist", company: "Brandify", location: "Chicago, IL" },
  ];

  // Search functionality
  const searchInput = document.getElementById('job-search');
  searchInput.addEventListener('input', () => {
    const query = searchInput.value.toLowerCase();
    const results = jobs.filter(job =>
      job.title.toLowerCase().includes(query) ||
      job.company.toLowerCase().includes(query) ||
      job.location.toLowerCase().includes(query)
    );

    // Display filtered results (you can expand this to show results on page)
    if (results.length > 0) {
      messageElement.textContent = `Found ${results.length} job(s) matching "${query}"`;
    } else {
      messageElement.textContent = `No jobs found for "${query}"`;
    }
  });

  // Testimonials data
  const testimonials = [
    {
      name: "Alice Johnson",
      text: "This job board helped me land my dream job in tech. Highly recommend!"
    },
    {
      name: "Mark Thompson",
      text: "Easy to use and great job listings. Found a great remote position thanks to this site."
    },
    {
      name: "Samantha Lee",
      text: "Posting jobs is simple and effective. My company found top talent quickly."
    }
  ];

  let testimonialIndex = 0;
  const testimonialContainer = document.getElementById('testimonial-container');
  const prevBtn = document.getElementById('prev-testimonial');
  const nextBtn = document.getElementById('next-testimonial');

  function showTestimonial(index) {
    const t = testimonials[index];
    testimonialContainer.innerHTML = `
      <blockquote>"${t.text}"</blockquote>
      <p><strong>- ${t.name}</strong></p>
    `;
  }

  showTestimonial(testimonialIndex);

  prevBtn.addEventListener('click', () => {
    testimonialIndex = (testimonialIndex - 1 + testimonials.length) % testimonials.length;
    showTestimonial(testimonialIndex);
  });

  nextBtn.addEventListener('click', () => {
    testimonialIndex = (testimonialIndex + 1) % testimonials.length;
    showTestimonial(testimonialIndex);
  });
});
