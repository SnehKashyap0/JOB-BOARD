document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('post-job-form');

  form.addEventListener('submit', (e) => {
    e.preventDefault();

    // Simple form validation
    const title = form.title.value.trim();
    const company = form.company.value.trim();
    const location = form.location.value.trim();
    const type = form.type.value;
    const description = form.description.value.trim();

    if (!title || !company || !location || !type || !description) {
      alert('Please fill in all fields before submitting.');
      return;
    }

    // Simulate successful submission
    alert('Job posted successfully!');

    // Clear the form after submission
    form.reset();
  });
});
