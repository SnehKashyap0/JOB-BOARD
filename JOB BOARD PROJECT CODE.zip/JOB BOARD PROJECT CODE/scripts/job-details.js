document.addEventListener('DOMContentLoaded', () => {
  const jobInfoContainer = document.getElementById('job-info');
  const applyBtn = document.getElementById('apply-btn');

  // Sample job data (same as jobs.js for demo)
  const jobs = [
    {
      id: 1,
      title: "Frontend Developer",
      company: "Tech Solutions",
      location: "New York, NY",
      type: "Full-time",
      description: "We are looking for a skilled frontend developer with experience in React and CSS."
    },
    {
      id: 2,
      title: "Backend Engineer",
      company: "Innovatech",
      location: "San Francisco, CA",
      type: "Full-time",
      description: "Seeking a backend engineer proficient in Node.js, databases, and API development."
    },
    {
      id: 3,
      title: "UI/UX Designer",
      company: "Creative Minds",
      location: "Remote",
      type: "Contract",
      description: "Looking for a creative UI/UX designer to craft engaging user experiences."
    }
  ];

  // Get job id from URL query string
  const urlParams = new URLSearchParams(window.location.search);
  const jobId = parseInt(urlParams.get('id'));

  if (!jobId) {
    jobInfoContainer.innerHTML = '<p>Job not found.</p>';
    return;
  }

  const job = jobs.find(j => j.id === jobId);

  if (!job) {
    jobInfoContainer.innerHTML = '<p>Job not found.</p>';
    return;
  }

  // Display job details
  jobInfoContainer.innerHTML = `
    <h2>${job.title}</h2>
    <p><strong>Company:</strong> ${job.company}</p>
    <p><strong>Location:</strong> ${job.location}</p>
    <p><strong>Type:</strong> ${job.type}</p>
    <p><strong>Description:</strong> ${job.description}</p>
  `;

  applyBtn.addEventListener('click', () => {
    alert(`You have applied for the position of ${job.title} at ${job.company}.`);
  });
});
