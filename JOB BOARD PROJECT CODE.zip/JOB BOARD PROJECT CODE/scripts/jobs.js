document.addEventListener('DOMContentLoaded', () => {
  const jobListingsContainer = document.getElementById('job-listings');

  // Sample job data (you can replace this with API calls later)
  const jobs = [
    {
      id: 1,
      title: "Frontend Developer",
      company: "Tech Solutions",
      location: "New York, NY",
      type: "Full-time"
    },
    {
      id: 2,
      title: "Backend Engineer",
      company: "Innovatech",
      location: "San Francisco, CA",
      type: "Full-time"
    },
    {
      id: 3,
      title: "UI/UX Designer",
      company: "Creative Minds",
      location: "Remote",
      type: "Contract"
    }
  ];

  // Function to render jobs
  function renderJobs() {
    jobs.forEach(job => {
      const jobDiv = document.createElement('div');
      jobDiv.classList.add('job-item');
      jobDiv.innerHTML = `
        <h3>${job.title}</h3>
        <p><strong>Company:</strong> ${job.company}</p>
        <p><strong>Location:</strong> ${job.location}</p>
        <p><strong>Type:</strong> ${job.type}</p>
      `;
      jobDiv.addEventListener('click', () => {
        // Navigate to job details page, passing job id in query string
        window.location.href = `job-details.html?id=${job.id}`;
      });
      jobListingsContainer.appendChild(jobDiv);
    });
  }

  renderJobs();
});
